#ifndef __DMA_REFRESH_LVGL_H__
#define __DMA_REFRESH_LVGL_H__

#include "lvgl.h"
#include "SEGGER_RTT.h"



void lv_gpu_stm32_dma2d_init();

#endif



